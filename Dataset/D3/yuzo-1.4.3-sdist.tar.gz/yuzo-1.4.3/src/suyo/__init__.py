"""suyo

Essential helper package for HamzaGSopp projects.
"""

from .core import init

__all__ = ["init"]

# Package-level debug flag. Set `suyo.debug = True` to enable debug prints in runtime.
debug = False

__author__ = "Suyo"
__version__ = "1.1.1"
