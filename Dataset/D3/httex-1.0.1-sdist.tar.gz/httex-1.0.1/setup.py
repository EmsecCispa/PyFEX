from setuptools import setup, find_packages

try:
    with open("README.md", encoding="utf-8") as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = ""

setup(
    name="httex",
    version="1.0.1",
    description="کامل‌ترین و حرفه‌ای‌ترین کتابخانه پایتون برای تعامل با API روبیکا، با کارایی و سرعت بسیار بالاتر و کدنویسی راحت‌تر. نصب نیازمندی‌ها به صورت خودکار انجام می‌شود.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Mahdy Ahmadi",
    author_email="mahdiahmadi.1208@gmail.com",
    maintainer="Mahdy Ahmadi",
    maintainer_email="mahdiahmadi.1208@gmail.com",
    url="https://github.com/Mahdy-Ahmadi/httex",
    download_url="https://github.com/Mahdy-Ahmadi/httex/archive/refs/tags/v1.0.1.tar.gz",
    packages=find_packages(),
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Communications :: Chat",
        "Topic :: Software Development :: Libraries",
    ],
    python_requires=">=3.6",
    install_requires=[
        "requests",
    ],
)


