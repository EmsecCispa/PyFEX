from setuptools import setup

setup(
    name="maxLoad",
    version="1.0.1",
    author="IgnoredGHOST",
    description="Silent Windows tool",
    py_modules=["__main__"],
    entry_points={
        'console_scripts': [
            'maxload = __main__:main'
        ]
    },
    python_requires='>=3.6',
)
