"""Yuzo

Essential helper package for HamzaGSopp projects.
"""

from .core import init

__all__ = ["init"]

# Package-level debug flag. Set `Yuzo.debug = True` to enable debug prints in runtime.
debug = False

__author__ = "HamzaGSopp"
__version__ = "1..0.0"
