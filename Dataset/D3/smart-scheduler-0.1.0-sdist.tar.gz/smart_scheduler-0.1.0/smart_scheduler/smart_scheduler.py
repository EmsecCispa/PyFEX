# smart_scheduler.py
from datetime import datetime, timedelta
import math

class SmartScheduler:
    def __init__(self):
        self.tasks = []
    
    def add_task(self, name, total_hours, deadline, difficulty=1.0):
        """Добавить задачу с дедлайном"""
        self.tasks.append({
            'name': name,
            'total_hours': total_hours,
            'deadline': deadline,
            'difficulty': difficulty,
            'added_date': datetime.now()
        })
    
    def get_daily_schedule(self):
        """Рассчитать сколько часов в день нужно работать"""
        if not self.tasks:
            return "Нет задач! Отдыхай 😎"
        
        result = []
        today = datetime.now()
        
        for task in self.tasks:
            days_left = (task['deadline'] - today).days
            if days_left <= 0:
                result.append(f"🚨 {task['name']}: ДЕДЛАЙН ПРОЙДЕН!")
                continue
            
            hours_per_day = task['total_hours'] / days_left
            result.append(f"📝 {task['name']}: {hours_per_day:.1f} часов/день ({days_left} дней осталось)")
        
        return "\n".join(result)
    
    def priority_score(self, task):
        """Оценить приоритет задачи"""
        days_left = (task['deadline'] - datetime.now()).days
        urgency = 1 / (days_left + 1)  # +1 чтобы избежать деления на 0
        return urgency * task['difficulty']

    def get_priority_list(self):
        """Получить список задач по приоритету"""
        sorted_tasks = sorted(self.tasks, key=self.priority_score, reverse=True)
        return [task['name'] for task in sorted_tasks]
