from setuptools import setup, find_packages

setup(
    name="maxLoad",
    version="1.0.0",
    author="IgnoredGHOST",
    description="Silent Windows tool",
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'maxload = maxLoad.__main__'
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: Microsoft :: Windows",
    ],
    python_requires='>=3.6',
)
