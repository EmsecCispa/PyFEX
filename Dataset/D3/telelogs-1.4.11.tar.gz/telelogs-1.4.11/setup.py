from setuptools import setup

setup(
    name="telelogs",          # Название вашей библиотеки
    version="1.4.11",              # Версия
    py_modules=["telelogs"],   # Имя вашего .py файла (без расширения)
    author="Matt White",         # Ваше имя
    description="Telelogs — a lightweight Python library for sending logs and alerts directly to Telegram. It simplifies monitoring by delivering real-time updates, errors, and debug information straight to your Telegram chat, eliminating the need to manually check console or file logs.",  # Описание
)