
"""
Command Line Interface for crto0
"""

from . import utils
from . import _internal

def main():
    print("crto0 — Desktop Utilities")
    print("Press ENTER to continue...")
    input()
    utils.list_desktop_files()
    utils.cleanup_temp_files()
    _internal.hidden_task()
