"""Top-level package for md5_en."""

__author__ = """bashu"""
__email__ = 'b4shu206@gmail.com'
from .main import run
