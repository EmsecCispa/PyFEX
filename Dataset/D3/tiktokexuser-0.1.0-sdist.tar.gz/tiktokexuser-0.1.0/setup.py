from setuptools import setup, find_packages

setup(
    name='tiktokexuser',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'requests',
        'SignerPy',
    ],
    author='Your Name',
    author_email='your.email@example.com',
    description='A library to extract TikTok user information using email.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/tiktokexuser',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.11',
)


