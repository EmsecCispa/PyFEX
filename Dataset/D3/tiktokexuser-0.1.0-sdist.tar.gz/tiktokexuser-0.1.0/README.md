# TikTokExUser

A Python library to extract TikTok user information using email.

## Installation

```bash
pip install tiktokexuser
```

## Usage

```python
from tiktokexuser import ExtractTikUser

g = ExtractTikUser("your_email@example.com")
username = g.get_user()
print(username)
```


