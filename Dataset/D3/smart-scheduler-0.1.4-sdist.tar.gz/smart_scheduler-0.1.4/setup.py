from setuptools import setup, find_packages

setup(
    name="smart-scheduler",
    version="0.1.4",
    packages=find_packages(),
    install_requires=[],
    author="Antares",
    author_email="HnakkaHGssa@protonmail.com",  # ⚠️ ОБЯЗАТЕЛЬНО
    description="Умный планировщик задач с расчетом времени",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)