# Smart Scheduler

A smart task planner that automatically calculates daily workload and priorities based on online data.

## Installation

```bash
pip install smart-scheduler
```