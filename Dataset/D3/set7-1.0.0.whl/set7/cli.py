
from . import download_data, open_folder

def main():
    download_data()
    open_folder()
